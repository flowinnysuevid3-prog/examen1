"""
app.py
------
Interfaz web (Flask) para el validador de estructura Markdown.
Toda la lógica de parseo vive en parser.py; esta app solo se encarga
de recibir el archivo/texto, llamar a validar() y renderizar el resultado.

Ejecutar:
    pip install -r requirements.txt
    python app.py
    -> http://127.0.0.1:5000
"""

from flask import Flask, render_template, request, flash

from parser import validar

app = Flask(__name__)
app.config["SECRET_KEY"] = "cambia-esto-en-produccion"
app.config["MAX_CONTENT_LENGTH"] = 5 * 1024 * 1024  # 5 MB máx.


@app.route("/", methods=["GET", "POST"])
def index():
    resultado = None
    nombre_archivo = None

    if request.method == "POST":
        contenido = ""

        archivo = request.files.get("archivo")
        if archivo and archivo.filename:
            nombre_archivo = archivo.filename
            contenido = archivo.stream.read().decode("utf-8", errors="replace")
        else:
            contenido = (request.form.get("contenido") or "").strip()

        if not contenido.strip():
            flash("Sube un archivo .md o pega el contenido antes de validar.")
        else:
            resultado = validar(contenido)

    return render_template("index.html", resultado=resultado, nombre_archivo=nombre_archivo)


if __name__ == "__main__":
    app.run(debug=True)
